from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.selector import Selector
from scrapy.linkextractors import LinkExtractor

from ..items import AmazonRankingItem

class Amazon_rankingSpider(CrawlSpider):

    name = "amazon_ranking"
    
    #start_urls = ["https://www.amazon.com/s?i=stripbooks&rh=p_30%3AForgotten+Books&s=relevanceexprank&page=3&Adv-Srch-Books-Submit.x=19&Adv-Srch-Books-Submit.y=9&qid=1585559030&unfiltered=1&ref=sr_pg_3"]
          
    def __init__(self, *args, **kwargs):                    
        super(Amazon_rankingSpider, self).__init__(*args, **kwargs) 
        
        file = open("input.txt","r")

        self.links = []

        for link in file.readlines():
            link = link.replace("\n","")
            self.links.append(link)

        file.close()


    def start_requests(self):

        for links in self.links:
            yield Request(url=links,callback=self.first)
            
    def first(self,response):
        
        
        yield response.follow(url=response.url,callback=self.ranking_filter)
        
        links = response.css(".a-spacing-micro.s-navigation-indent-2 a::attr(href)").extract()
        
        for link in links:
            yield response.follow(url=link,callback=self.second)
    
    def second(self,response):
        
        yield response.follow(url=response.url,callback=self.ranking_filter)
        
        links = response.css(".a-spacing-micro.s-navigation-indent-2 a::attr(href)").extract()
        
        for link in links:
            yield response.follow(url=link,callback=self.third)
    
    def third(self,response):
        
        yield response.follow(url=response.url,callback=self.ranking_filter)
        
        links = response.css(".a-spacing-micro.s-navigation-indent-2 a::attr(href)").extract()
        
        if links == None:
            yield response.follow(url=response.url,callback=self.ranking_filter)
        
        for link in links:
            yield response.follow(url=link,callback=self.fourth)

    def fourth(self,response):
        
        links = response.css(".a-spacing-micro.s-navigation-indent-2 a::attr(href)").extract()
        
        for link in links:
            yield response.follow(url=link,callback=self.ranking_filter)
            
    
    def ranking_filter(self,response):
        
        for filters in  ["&ref=sr_st_price-asc-rank","&ref=sr_st_price-desc-rank","&ref=sr_st_review-rank","&ref=sr_st_date-desc-rank","&ref=sr_st_review-count-rank"]:
            temp = response.url
            temp = temp.replace("&ref=sr_st_featured-rank","")
            yield response.follow(url=temp+filters,callback=self.ranking_stars)
            
    def ranking_stars(self,response):
        
        links = response.css("ul[aria-labelledby='p_72-title'] li a::attr(href)").extract()
        
        for link in links:
            yield response.follow(url=link,callback=self.ranking_langauge)
    
    
    def ranking_langauge(self,response):
        
        links = response.css("ul[aria-labelledby='p_n_feature_nine_browse-bin-title'] li a::attr(href)").extract()
        
        for link in links:
            yield response.follow(url=link,callback=self.page)

    
    def page(self,response):
        
        links = response.css("span[data-component-type='s-product-image'] .a-link-normal::attr(href)").extract()
        
        for link in links:        
            yield response.follow(url=link,callback=self.rank_page)
        
        
        next_page = response.css(".a-last a::attr(href)").extract_first()
        
        if next_page:
           yield response.follow(url=next_page,callback=self.page)
            
    
    def rank_page(self,response):

        check = response.css(".a-button.a-button-selected.a-spacing-mini.a-button-toggle.format .a-button-text > span:first-child::text").extract_first()
      
        if check and check in 'Paperback':
            yield self.extract_data(response)
        else:
            
            paperback = response.xpath("//span[contains(text(), 'Paperback')]/parent::a/@href").extract_first()

            if paperback:
                yield response.follow(url=paperback,callback=self.paper_back)

                
    def paper_back(self,response):
        yield self.extract_data(response)        
                
    def extract_data(self,response):
                    
        title = response.css("#productTitle::text").extract_first()
        
        publisher = response.xpath('//li/b[contains(text(),"Publisher:")]/parent::li/text()').extract()
        
        rank = response.css("#SalesRank::text").extract()
        
        if rank:
            rank = "".join(rank)
            rank = rank.replace("\n","")
            rank = rank.replace("in Books ()","")
            rank = rank.replace("#","")
            rank = rank.strip()
        
        source_url = response.url
        
        item = AmazonRankingItem()
        
        item["name"] = title
        item["publisher"] = publisher
        item["rank"] = rank
        item["source_url"] = source_url
        
        
        return item